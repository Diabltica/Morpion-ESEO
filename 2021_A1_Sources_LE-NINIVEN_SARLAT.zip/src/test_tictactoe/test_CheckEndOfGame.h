/**
 * @file test_checkEndOfGame.h
 *
 * @date 27 oct. 2016
 * @author jilias
 */

#if !defined TEST_CHECKENDOFGAME_H_
#define TEST_CHECKENDOFGAME_H_

extern void testCheckEndOfGame (void);

#endif /* !defined TEST_CHECKENDOFGAME_H_ */
